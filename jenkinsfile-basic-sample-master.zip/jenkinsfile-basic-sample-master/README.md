# Jenkinsfile basic sample

Jenkinsfile basic configuration example with stages definition to set up a Continuous Delivery Pipeline.

This repository has was created to provide an example for the following tutorial about how to set up Jenkins Pipelines:

* [Setup Continuos Integration/Delivery system in just 4 steps with Jenkins Pipelines and Blue Ocean](https://dev.to/jalogut/setup-continuos-integrationdelivery-system-in-just-4-steps-with-jenkins-pipelines-and-blue-ocean)
